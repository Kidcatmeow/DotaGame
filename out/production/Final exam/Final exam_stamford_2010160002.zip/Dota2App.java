import java.util.Scanner;

public class Dota2App {

    public static void main (String[]args){
        System.out.print("Player A, pick a hero (select 1-10):");
        Scanner input = new Scanner(System.in);
        int user_input = input.nextInt();
        Hero PlayerA_hero1 = new Hero(user_input);
        System.out.print("Player A, pick a hero (select 1-10):");
        Scanner input2 = new Scanner(System.in);
        int user_input2 = input.nextInt();
        Hero PlayerA_hero2 = new Hero(user_input2);
        System.out.print("Player A, pick a hero (select 1-10):");
        Scanner input3 = new Scanner(System.in);
        int user_input3 = input.nextInt();
        Hero PlayerA_hero3 = new Hero(user_input3);
        System.out.print("Player B, pick a hero (select 1-10):");
        Scanner input4 = new Scanner(System.in);
        int user_input4 = input.nextInt();
        Hero PlayerB_hero1 = new Hero(user_input4);
        System.out.print("Player B, pick a hero (select 1-10):");
        Scanner input5 = new Scanner(System.in);
        int user_input5= input.nextInt();
        Hero PlayerB_hero2 = new Hero(user_input5);
        System.out.print("Player B, pick a hero (select 1-10):");
        Scanner input6 = new Scanner(System.in);
        int user_input6 = input.nextInt();
        Hero PlayerB_hero3 = new Hero(user_input6);

        while(true){
            System.out.printf("%-15s %-15s\n",
                    "Player A", "Player B");
            String Hero1name = PlayerA_hero1.name;
            Float  Hero1dmg =PlayerA_hero1.damage;
            Float Hero1HP = PlayerA_hero1.HP;
            Float Hero1MP = PlayerA_hero1.MP;
            System.out.printf("%-5s (%5s) %5s/%5s \n",
                    Hero1name,Hero1dmg, Hero1HP,Hero1MP);
            String Hero2name = PlayerA_hero2.name;
            Float  Hero2dmg =PlayerA_hero2.damage;
            Float Hero2HP = PlayerA_hero2.HP;
            Float Hero2MP = PlayerA_hero2.MP;
            System.out.printf("%-5s (%5s) %5s/%5s \n",
                    Hero2name,Hero2dmg, Hero2HP,Hero2MP);
            String Hero3name = PlayerA_hero3.name;
            Float  Hero3dmg =PlayerA_hero3.damage;
            Float Hero3HP = PlayerA_hero3.HP;
            Float Hero3MP = PlayerA_hero3.MP;
            System.out.printf("%-5s (%5s) %5s/%5s \n",
                    Hero3name,Hero3dmg, Hero3HP,Hero3MP);
            String Hero4name = PlayerB_hero1.name;
            Float  Hero4dmg =PlayerB_hero1.damage;
            Float Hero4HP = PlayerB_hero1.HP;
            Float Hero4MP = PlayerB_hero1.MP;
            System.out.printf("%-5s (%5s) %5s/%5s \n",
                    Hero3name,Hero3dmg, Hero3HP,Hero3MP);
            break;

        }
    }

//    public static void hero_status(Hero hero){
//        System.out.printf("%-5s (%5s) %5s/%5s \n",Hero.ge
//    }
}
